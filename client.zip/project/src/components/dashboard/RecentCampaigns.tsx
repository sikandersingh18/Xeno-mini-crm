import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  date: string;
  segment: string;
  sent: number;
  delivered: number;
  failed: number;
}

const campaigns: Campaign[] = [
  {
    id: '1',
    name: 'Summer Sale Promo',
    date: 'May 28, 2025',
    segment: 'High Spenders',
    sent: 2450,
    delivered: 2300,
    failed: 150
  },
  {
    id: '2',
    name: 'Inactive Customers',
    date: 'May 26, 2025',
    segment: 'Inactive 90 Days',
    sent: 1850,
    delivered: 1750,
    failed: 100
  },
  {
    id: '3',
    name: 'New Product Launch',
    date: 'May 24, 2025',
    segment: 'Frequent Buyers',
    sent: 3200,
    delivered: 3100,
    failed: 100
  },
  {
    id: '4',
    name: 'Feedback Request',
    date: 'May 22, 2025',
    segment: 'Recent Purchasers',
    sent: 1500,
    delivered: 1450,
    failed: 50
  }
];

const RecentCampaigns: React.FC = () => {
  return (
    <div className="space-y-4">
      {campaigns.map((campaign) => (
        <div key={campaign.id} className="border border-gray-200 dark:border-dark-400 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium">{campaign.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{campaign.date}</p>
            </div>
            <span className="px-2 py-1 bg-gray-100 dark:bg-dark-100 text-xs rounded-full">
              {campaign.segment}
            </span>
          </div>
          
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Sent</p>
              <p className="font-medium">{campaign.sent}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Delivered</p>
              <div className="font-medium flex items-center justify-center">
                <CheckCircle className="h-3 w-3 text-success-500 mr-1" />
                {campaign.delivered}
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 dark:text-gray-400">Failed</p>
              <div className="font-medium flex items-center justify-center">
                <XCircle className="h-3 w-3 text-error-500 mr-1" />
                {campaign.failed}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RecentCampaigns;