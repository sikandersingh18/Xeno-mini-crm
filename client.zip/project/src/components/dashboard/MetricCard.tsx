import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  change: number;
  changeType: 'increase' | 'decrease';
  icon: React.ReactNode;
  iconColor: string;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  change,
  changeType,
  icon,
  iconColor,
}) => {
  return (
    <div className="card">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</h3>
          <p className="text-2xl font-semibold mt-2">{value}</p>
          <div className="flex items-center mt-2">
            <div className={`flex items-center ${
              changeType === 'increase' 
                ? 'text-success-600' 
                : 'text-error-600'
            }`}>
              {changeType === 'increase' 
                ? <ArrowUpRight className="h-4 w-4 mr-1" /> 
                : <ArrowDownRight className="h-4 w-4 mr-1" />
              }
              <span className="text-sm font-medium">{change}%</span>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">vs last period</span>
          </div>
        </div>
        <div className={`rounded-full p-3 ${iconColor}`}>
          {icon}
        </div>
      </div>
    </div>
  );
};

export default MetricCard;