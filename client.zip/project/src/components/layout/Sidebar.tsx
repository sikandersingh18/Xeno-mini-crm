import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  BarChart2, 
  Settings, 
  Mail, 
  ChevronLeft, 
  ChevronRight 
} from 'lucide-react';
import clsx from 'clsx';

interface SidebarProps {
  collapsed: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed, toggleSidebar }) => {
  return (
    <div 
      className={clsx(
        'h-screen bg-white dark:bg-dark-200 border-r border-gray-200 dark:border-dark-400 transition-all duration-300 flex flex-col',
        {
          'w-16': collapsed,
          'w-64': !collapsed,
        }
      )}
    >
      <div className="p-4 flex items-center justify-between border-b border-gray-200 dark:border-dark-400">
        {!collapsed && (
          <div className="font-bold text-xl text-primary-600 dark:text-primary-400">Xeno_mini-crm</div>
        )}
        <button 
          onClick={toggleSidebar}
          className="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100"
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>

      <nav className="flex-1 p-3 overflow-y-auto">
        <NavLink 
          to="/" 
          className={({ isActive }) => 
            clsx('sidebar-link', { 'active': isActive })
          }
        >
          <LayoutDashboard className="mr-3" size={20} />
          {!collapsed && <span>Dashboard</span>}
        </NavLink>

        <NavLink 
          to="/segments" 
          className={({ isActive }) => 
            clsx('sidebar-link', { 'active': isActive })
          }
        >
          <Users className="mr-3" size={20} />
          {!collapsed && <span>Audience Segments</span>}
        </NavLink>

        <NavLink 
          to="/campaigns" 
          className={({ isActive }) => 
            clsx('sidebar-link', { 'active': isActive })
          }
        >
          <Mail className="mr-3" size={20} />
          {!collapsed && <span>Campaigns</span>}
        </NavLink>

        <NavLink 
          to="/reports" 
          className={({ isActive }) => 
            clsx('sidebar-link', { 'active': isActive })
          }
        >
          <BarChart2 className="mr-3" size={20} />
          {!collapsed && <span>Reports</span>}
        </NavLink>

        <NavLink 
          to="/settings" 
          className={({ isActive }) => 
            clsx('sidebar-link', { 'active': isActive })
          }
        >
          <Settings className="mr-3" size={20} />
          {!collapsed && <span>Settings</span>}
        </NavLink>
      </nav>

      <div className="p-4 border-t border-gray-200 dark:border-dark-400">
        {!collapsed && (
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Xeno_mini-crm v1.0.0
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;