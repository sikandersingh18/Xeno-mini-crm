import React from 'react';
import { Bell, Search, Moon, Sun, User } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="bg-white dark:bg-dark-200 border-b border-gray-200 dark:border-dark-400 h-16 flex items-center px-6 justify-between">
      <div className="relative w-80">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="input pl-10 w-full"
          placeholder="Search..."
        />
      </div>
      
      <div className="flex items-center space-x-4">
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100"
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        
        <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100 relative">
          <Bell size={20} />
          <span className="absolute top-1 right-1 h-2 w-2 bg-error-500 rounded-full"></span>
        </button>
        
        <div className="flex items-center space-x-3">
          <div className="text-right hidden md:block">
            <div className="text-sm font-medium">Sikander Singh</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Admin</div>
          </div>
          <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium">
            <User size={20} />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;