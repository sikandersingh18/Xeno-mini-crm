import React, { useState } from 'react';
import { Plus, X, MoveVertical } from 'lucide-react';
import RuleGroup from './RuleGroup';
import { v4 as uuidv4 } from 'uuid';

export interface Rule {
  id: string;
  field: string;
  operator: string;
  value: string;
}

export interface RuleGroupType {
  id: string;
  combinator: 'AND' | 'OR';
  rules: Rule[];
}

const initialRule: Rule = {
  id: uuidv4(),
  field: 'spend',
  operator: '>',
  value: ''
};

const initialRuleGroup: RuleGroupType = {
  id: uuidv4(),
  combinator: 'AND',
  rules: [initialRule]
};

const RuleBuilder: React.FC = () => {
  const [ruleGroups, setRuleGroups] = useState<RuleGroupType[]>([initialRuleGroup]);

  const addRuleGroup = () => {
    const newGroup: RuleGroupType = {
      id: uuidv4(),
      combinator: 'OR',
      rules: [{ id: uuidv4(), field: 'spend', operator: '>', value: '' }]
    };
    
    setRuleGroups([...ruleGroups, newGroup]);
  };

  const removeRuleGroup = (groupId: string) => {
    if (ruleGroups.length === 1) {
      return; // Don't remove the last group
    }
    setRuleGroups(ruleGroups.filter(group => group.id !== groupId));
  };

  const updateRuleGroup = (updatedGroup: RuleGroupType) => {
    setRuleGroups(ruleGroups.map(group => 
      group.id === updatedGroup.id ? updatedGroup : group
    ));
  };

  return (
    <div className="space-y-4">
      {ruleGroups.map((group, index) => (
        <div key={group.id} className="rule-group relative">
          {index > 0 && (
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-gray-100 dark:bg-dark-100 px-3 py-1 rounded-t-md text-sm font-medium">
              OR
            </div>
          )}
          <div className="flex justify-between items-start mb-3">
            <h3 className="font-medium">Rule Group {index + 1}</h3>
            {ruleGroups.length > 1 && (
              <button 
                onClick={() => removeRuleGroup(group.id)}
                className="p-1 rounded text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <RuleGroup
            group={group}
            onChange={updateRuleGroup}
          />
        </div>
      ))}

      <div className="flex justify-center mt-6">
        <button 
          onClick={addRuleGroup}
          className="flex items-center px-4 py-2 border border-dashed border-gray-300 dark:border-dark-400 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-100"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Rule Group (OR)
        </button>
      </div>
    </div>
  );
};

export default RuleBuilder;