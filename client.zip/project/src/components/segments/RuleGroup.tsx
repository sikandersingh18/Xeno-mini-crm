import React from 'react';
import { Plus, X } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { Rule, RuleGroupType } from './RuleBuilder';

interface RuleGroupProps {
  group: RuleGroupType;
  onChange: (group: RuleGroupType) => void;
}

const fields = [
  { value: 'spend', label: 'Total Spend' },
  { value: 'visits', label: 'Number of Visits' },
  { value: 'inactive_days', label: 'Inactive Days' },
  { value: 'purchase_count', label: 'Purchase Count' },
  { value: 'average_order', label: 'Average Order Value' }
];

const operators = [
  { value: '>', label: 'Greater Than' },
  { value: '<', label: 'Less Than' },
  { value: '=', label: 'Equal To' },
  { value: '>=', label: 'Greater Than or Equal To' },
  { value: '<=', label: 'Less Than or Equal To' },
  { value: '!=', label: 'Not Equal To' }
];

const RuleGroup: React.FC<RuleGroupProps> = ({ group, onChange }) => {
  const handleCombinatorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onChange({
      ...group,
      combinator: e.target.value as 'AND' | 'OR'
    });
  };

  const handleRuleChange = (ruleId: string, field: string, value: string) => {
    const updatedRules = group.rules.map(rule => {
      if (rule.id === ruleId) {
        return { ...rule, [field]: value };
      }
      return rule;
    });
    
    onChange({
      ...group,
      rules: updatedRules
    });
  };

  const addRule = () => {
    const newRule: Rule = {
      id: uuidv4(),
      field: 'spend',
      operator: '>',
      value: ''
    };
    
    onChange({
      ...group,
      rules: [...group.rules, newRule]
    });
  };

  const removeRule = (ruleId: string) => {
    if (group.rules.length === 1) {
      return; // Don't remove the last rule
    }
    
    onChange({
      ...group,
      rules: group.rules.filter(rule => rule.id !== ruleId)
    });
  };

  return (
    <div>
      <div className="rule-operators">
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Combine with:</span>
        <select
          value={group.combinator}
          onChange={handleCombinatorChange}
          className="input py-1"
        >
          <option value="AND">AND</option>
          <option value="OR">OR</option>
        </select>
      </div>

      <div className="space-y-3">
        {group.rules.map((rule, index) => (
          <div key={rule.id} className="rule-condition">
            <select
              value={rule.field}
              onChange={(e) => handleRuleChange(rule.id, 'field', e.target.value)}
              className="input py-1"
            >
              {fields.map(field => (
                <option key={field.value} value={field.value}>
                  {field.label}
                </option>
              ))}
            </select>
            
            <select
              value={rule.operator}
              onChange={(e) => handleRuleChange(rule.id, 'operator', e.target.value)}
              className="input py-1"
            >
              {operators.map(op => (
                <option key={op.value} value={op.value}>
                  {op.label}
                </option>
              ))}
            </select>
            
            <input
              type="text"
              value={rule.value}
              onChange={(e) => handleRuleChange(rule.id, 'value', e.target.value)}
              className="input py-1"
              placeholder="Value"
            />
            
            <button
              onClick={() => removeRule(rule.id)}
              className="p-1.5 rounded text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100"
              title="Remove Rule"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
      
      <button
        onClick={addRule}
        className="mt-3 flex items-center px-3 py-1.5 text-sm border border-dashed border-gray-300 dark:border-dark-400 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-100"
      >
        <Plus className="h-3 w-3 mr-1" />
        Add Condition
      </button>
    </div>
  );
};

export default RuleGroup;