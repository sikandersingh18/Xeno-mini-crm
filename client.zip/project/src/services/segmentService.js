import api from '../config/api.config';

export const segmentService = {
  getSegments: async () => {
    const response = await api.get('/segments');
    return response.data;
  },

  createSegment: async (segment) => {
    const response = await api.post('/segments', segment);
    return response.data;
  },

  updateSegment: async (id, segment) => {
    const response = await api.put(`/segments/${id}`, segment);
    return response.data;
  },

  deleteSegment: async (id) => {
    await api.delete(`/segments/${id}`);
  },

  previewAudienceSize: async (rules) => {
    const response = await api.post('/segments/preview', { rules });
    return response.data.size;
  }
};