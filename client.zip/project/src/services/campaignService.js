import api from '../config/api.config';

export const campaignService = {
  getCampaigns: async () => {
    const response = await api.get('/campaigns');
    return response.data;
  },

  createCampaign: async (campaign) => {
    const response = await api.post('/campaigns', campaign);
    return response.data;
  },

  getCampaign: async (id) => {
    const response = await api.get(`/campaigns/${id}`);
    return response.data;
  },

  getCampaignLogs: async (campaignId) => {
    const response = await api.get(`/campaigns/${campaignId}/logs`);
    return response.data;
  },

  getCampaignStats: async (dateRange) => {
    const response = await api.get('/campaigns/stats', { params: dateRange });
    return response.data;
  }
};