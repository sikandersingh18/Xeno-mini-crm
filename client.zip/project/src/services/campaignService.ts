import api from '../config/api.config';

export interface Campaign {
  id: string;
  name: string;
  segmentId: string;
  segmentName: string;
  createdAt: Date;
  status: 'Completed' | 'In Progress' | 'Failed';
  audienceSize: number;
  sent: number;
  delivered: number;
  failed: number;
}

export interface CommunicationLog {
  id: string;
  campaignId: string;
  customerId: string;
  customerName: string;
  status: 'SENT' | 'FAILED' | 'PENDING';
  message: string;
  sentAt: Date;
  updatedAt: Date;
}

export const campaignService = {
  // Get all campaigns
  getCampaigns: async () => {
    const response = await api.get<Campaign[]>('/campaigns');
    return response.data;
  },

  // Create new campaign
  createCampaign: async (campaign: { name: string; segmentId: string }) => {
    const response = await api.post<Campaign>('/campaigns', campaign);
    return response.data;
  },

  // Get campaign details
  getCampaign: async (id: string) => {
    const response = await api.get<Campaign>(`/campaigns/${id}`);
    return response.data;
  },

  // Get campaign logs
  getCampaignLogs: async (campaignId: string) => {
    const response = await api.get<CommunicationLog[]>(`/campaigns/${campaignId}/logs`);
    return response.data;
  },

  // Get campaign statistics
  getCampaignStats: async (dateRange: { start: string; end: string }) => {
    const response = await api.get('/campaigns/stats', { params: dateRange });
    return response.data;
  }
};