import api from '../config/api.config';
import { Rule, RuleGroupType } from '../components/segments/RuleBuilder';

export interface Segment {
  id: string;
  name: string;
  description: string;
  rules: RuleGroupType[];
  audienceSize: number;
  createdAt: string;
  lastUsed: string;
}

export const segmentService = {
  // Get all segments
  getSegments: async () => {
    const response = await api.get<Segment[]>('/segments');
    return response.data;
  },

  // Create new segment
  createSegment: async (segment: Omit<Segment, 'id' | 'createdAt' | 'lastUsed'>) => {
    const response = await api.post<Segment>('/segments', segment);
    return response.data;
  },

  // Update segment
  updateSegment: async (id: string, segment: Partial<Segment>) => {
    const response = await api.put<Segment>(`/segments/${id}`, segment);
    return response.data;
  },

  // Delete segment
  deleteSegment: async (id: string) => {
    await api.delete(`/segments/${id}`);
  },

  // Preview audience size
  previewAudienceSize: async (rules: RuleGroupType[]) => {
    const response = await api.post<{ size: number }>('/segments/preview', { rules });
    return response.data.size;
  }
};