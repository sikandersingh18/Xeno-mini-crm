import React from 'react';
import { Save, UserCog, Bell, Key, Globe, Trash2 } from 'lucide-react';

const Settings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Settings</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="card sticky top-6">
            <nav className="space-y-1">
              <a href="#account" className="flex items-center px-3 py-2 text-primary-600 bg-primary-50 dark:bg-dark-100 dark:text-primary-400 rounded-md font-medium">
                <UserCog className="h-5 w-5 mr-3" />
                Account
              </a>
              <a href="#notifications" className="flex items-center px-3 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-100 rounded-md">
                <Bell className="h-5 w-5 mr-3" />
                Notifications
              </a>
              <a href="#api" className="flex items-center px-3 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-100 rounded-md">
                <Key className="h-5 w-5 mr-3" />
                API Keys
              </a>
              <a href="#vendor" className="flex items-center px-3 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-100 rounded-md">
                <Globe className="h-5 w-5 mr-3" />
                Vendor Settings
              </a>
            </nav>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div id="account" className="card">
            <h2 className="font-semibold mb-6">Account Settings</h2>
            
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="h-16 w-16 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-medium text-xl">
                  SS
                </div>
                <div>
                  <h3 className="font-medium">Profile Picture</h3>
                  <div className="flex space-x-2 mt-2">
                    <button className="btn btn-ghost text-sm py-1">Upload New</button>
                    <button className="btn btn-ghost text-sm py-1 text-error-600">Remove</button>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    First Name
                  </label>
                  <input type="text" className="input w-full" defaultValue="Sikander" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Last Name
                  </label>
                  <input type="text" className="input w-full" defaultValue="Singh" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Email Address
                  </label>
                  <input type="email" className="input w-full" defaultValue="Sikandersingh1823@gmail.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Phone Number
                  </label>
                  <input type="tel" className="input w-full" defaultValue="+1 (555) 123-4567" />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Company Name
                </label>
                <input type="text" className="input w-full" defaultValue="Acme Inc." />
              </div>
              
              <div className="pt-4 border-t border-gray-200 dark:border-dark-400">
                <button className="btn btn-primary flex items-center">
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </button>
              </div>
            </div>
          </div>

          <div id="notifications" className="card">
            <h2 className="font-semibold mb-6">Notification Settings</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div>
                  <h3 className="font-medium">Campaign Completion</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Get notified when a campaign is completed</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between py-2 border-t border-gray-200 dark:border-dark-400">
                <div>
                  <h3 className="font-medium">Delivery Failures</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Get notified when delivery failures exceed threshold</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between py-2 border-t border-gray-200 dark:border-dark-400">
                <div>
                  <h3 className="font-medium">New Feature Announcements</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Receive updates about new features and improvements</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between py-2 border-t border-gray-200 dark:border-dark-400">
                <div>
                  <h3 className="font-medium">Segment Updates</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Get notified about significant changes in segment sizes</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
            </div>
          </div>

          <div id="api" className="card">
            <h2 className="font-semibold mb-6">API Keys</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Production API Key
                </label>
                <div className="flex">
                  <input 
                    type="password" 
                    className="input rounded-r-none w-full" 
                    value="sk_prod_2a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d" 
                    readOnly
                  />
                  <button className="btn btn-ghost border border-l-0 border-gray-300 dark:border-dark-500 rounded-l-none">
                    Show
                  </button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Test API Key
                </label>
                <div className="flex">
                  <input 
                    type="password" 
                    className="input rounded-r-none w-full" 
                    value="sk_test_9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2" 
                    readOnly
                  />
                  <button className="btn btn-ghost border border-l-0 border-gray-300 dark:border-dark-500 rounded-l-none">
                    Show
                  </button>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-200 dark:border-dark-400">
                <button className="btn btn-primary">
                  Regenerate API Keys
                </button>
              </div>
            </div>
          </div>

          <div id="vendor" className="card">
            <h2 className="font-semibold mb-6">Vendor API Settings</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Vendor API Endpoint
                </label>
                <input type="url" className="input w-full" defaultValue="https://api.messaging-vendor.com/v1/send" />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Vendor API Key
                </label>
                <div className="flex">
                  <input 
                    type="password" 
                    className="input rounded-r-none w-full" 
                    value="vendor_api_3e2d1c0b9a8f7e6d5c4b3a2d1c0b9a8f" 
                    readOnly
                  />
                  <button className="btn btn-ghost border border-l-0 border-gray-300 dark:border-dark-500 rounded-l-none">
                    Show
                  </button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Webhook Callback URL
                </label>
                <div className="flex">
                  <input 
                    type="text" 
                    className="input rounded-r-none w-full" 
                    value="https://api.camptrack.io/webhooks/delivery-status" 
                    readOnly
                  />
                  <button className="btn btn-ghost border border-l-0 border-gray-300 dark:border-dark-500 rounded-l-none">
                    Copy
                  </button>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Configure this URL in your vendor dashboard to receive delivery status updates
                </p>
              </div>
              
              <div className="pt-4 border-t border-gray-200 dark:border-dark-400">
                <button className="btn btn-primary flex items-center">
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </button>
              </div>
            </div>
          </div>

          <div className="card bg-error-50 dark:bg-dark-200 border border-error-200 dark:border-error-800">
            <h2 className="font-semibold text-error-800 dark:text-error-300 mb-4">Danger Zone</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-error-800 dark:text-error-300">Delete Account</h3>
                  <p className="text-sm text-error-600 dark:text-error-400">
                    Once you delete your account, there is no going back. This action cannot be undone.
                  </p>
                </div>
                <button className="btn bg-error-600 hover:bg-error-700 text-white flex items-center">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Account
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;