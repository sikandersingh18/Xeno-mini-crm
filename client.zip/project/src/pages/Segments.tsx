import React from 'react';
import { Plus, Search, Edit, Trash2, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Segment {
  id: string;
  name: string;
  description: string;
  audienceSize: number;
  createdAt: string;
  lastUsed: string;
}

const segments: Segment[] = [
  {
    id: '1',
    name: 'High Value Customers',
    description: 'Customers who spent over ₹10,000 in the last 3 months',
    audienceSize: 1250,
    createdAt: 'May 20, 2025',
    lastUsed: 'May 28, 2025'
  },
  {
    id: '2',
    name: 'Inactive Customers',
    description: 'Customers inactive for more than 90 days',
    audienceSize: 3450,
    createdAt: 'May 15, 2025',
    lastUsed: 'May 26, 2025'
  },
  {
    id: '3',
    name: 'New Customers',
    description: 'Customers who made their first purchase in the last 30 days',
    audienceSize: 890,
    createdAt: 'May 10, 2025',
    lastUsed: 'May 24, 2025'
  },
  {
    id: '4',
    name: 'Frequent Shoppers',
    description: 'Customers with 5+ orders in the last 6 months',
    audienceSize: 720,
    createdAt: 'May 5, 2025',
    lastUsed: 'May 22, 2025'
  }
];

const Segments: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Audience Segments</h1>
        <Link to="/segments/create" className="btn btn-primary flex items-center">
          <Plus className="h-4 w-4 mr-2" />
          Create Segment
        </Link>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-semibold">Your Segments</h2>
          <div className="relative w-64">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="text"
              className="input pl-9 w-full py-2"
              placeholder="Search segments..."
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-dark-400">
                <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Segment Name</th>
                <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Description</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Audience Size</th>
                <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Created</th>
                <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Last Used</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody>
              {segments.map((segment) => (
                <tr key={segment.id} className="border-b border-gray-200 dark:border-dark-400 hover:bg-gray-50 dark:hover:bg-dark-100">
                  <td className="py-3 px-4 font-medium">{segment.name}</td>
                  <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{segment.description}</td>
                  <td className="py-3 px-4 text-center">
                    <div className="inline-flex items-center bg-primary-50 dark:bg-dark-100 text-primary-600 dark:text-primary-400 px-2 py-1 rounded">
                      <Users className="h-3 w-3 mr-1" />
                      {segment.audienceSize.toLocaleString()}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{segment.createdAt}</td>
                  <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{segment.lastUsed}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center justify-center space-x-2">
                      <button className="p-1.5 rounded text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="p-1.5 rounded text-gray-500 hover:bg-gray-100 dark:hover:bg-dark-100">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Segments;