import React from 'react';
import { DownloadCloud, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartData,
  ChartOptions
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const Reports: React.FC = () => {
  // Campaign delivery rates data
  const deliveryRatesData: ChartData<'line'> = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Delivery Rate',
        data: [92, 91, 93, 90, 94, 93],
        borderColor: '#7c3aed',
        backgroundColor: 'rgba(124, 58, 237, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Failure Rate',
        data: [8, 9, 7, 10, 6, 7],
        borderColor: '#ef4444',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  const deliveryRatesOptions: ChartOptions<'line'> = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          usePointStyle: true,
          boxWidth: 6
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      },
      x: {
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      }
    }
  };

  // Segment performance data
  const segmentPerformanceData: ChartData<'line'> = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'High Spenders',
        data: [3200, 3500, 3800, 4100, 4500, 4800],
        borderColor: '#7c3aed',
        backgroundColor: 'rgba(124, 58, 237, 0.5)',
        tension: 0.4,
      },
      {
        label: 'Frequent Buyers',
        data: [2800, 3100, 3300, 3200, 3600, 3700],
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        tension: 0.4,
      },
      {
        label: 'New Customers',
        data: [1500, 1800, 2200, 2400, 2600, 2800],
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.5)',
        tension: 0.4,
      }
    ]
  };

  const segmentPerformanceOptions: ChartOptions<'line'> = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          usePointStyle: true,
          boxWidth: 6
        }
      },
      tooltip: {
        mode: 'index',
        intersect: false
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      },
      x: {
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Reports & Analytics</h1>
        <button className="btn btn-ghost flex items-center">
          <DownloadCloud className="h-4 w-4 mr-2" />
          Export Data
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Campaigns</h3>
          <p className="text-2xl font-semibold mt-2">56</p>
          <div className="flex items-center mt-2">
            <div className="flex items-center text-success-600">
              <ArrowUpRight className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">12%</span>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">vs last month</span>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Messages Sent</h3>
          <p className="text-2xl font-semibold mt-2">124,512</p>
          <div className="flex items-center mt-2">
            <div className="flex items-center text-success-600">
              <ArrowUpRight className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">18%</span>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">vs last month</span>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Delivery Rate</h3>
          <p className="text-2xl font-semibold mt-2">93.2%</p>
          <div className="flex items-center mt-2">
            <div className="flex items-center text-success-600">
              <ArrowUpRight className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">2.1%</span>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">vs last month</span>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Failure Rate</h3>
          <p className="text-2xl font-semibold mt-2">6.8%</p>
          <div className="flex items-center mt-2">
            <div className="flex items-center text-error-600">
              <ArrowDownRight className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">2.1%</span>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">vs last month</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold">Delivery Rates Over Time</h2>
            <select className="input py-1">
              <option>Last 6 months</option>
              <option>Last 12 months</option>
              <option>Last 24 months</option>
            </select>
          </div>
          <Line data={deliveryRatesData} options={deliveryRatesOptions} />
        </div>
        
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold">Segment Performance</h2>
            <select className="input py-1">
              <option>Last 6 months</option>
              <option>Last 12 months</option>
              <option>Last 24 months</option>
            </select>
          </div>
          <Line data={segmentPerformanceData} options={segmentPerformanceOptions} />
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-semibold">Campaign Summary</h2>
          <select className="input py-1">
            <option>Last 30 days</option>
            <option>Last 90 days</option>
            <option>Last 180 days</option>
          </select>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-dark-400">
                <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Campaign Name</th>
                <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Segment</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Audience Size</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Sent</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Delivered</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Failed</th>
                <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Delivery Rate</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200 dark:border-dark-400 hover:bg-gray-50 dark:hover:bg-dark-100">
                <td className="py-3 px-4 font-medium">Summer Sale Promo</td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">High Spenders</td>
                <td className="py-3 px-4 text-center">1,250</td>
                <td className="py-3 px-4 text-center">1,250</td>
                <td className="py-3 px-4 text-center text-success-600">1,150</td>
                <td className="py-3 px-4 text-center text-error-600">100</td>
                <td className="py-3 px-4 text-center">92.0%</td>
              </tr>
              <tr className="border-b border-gray-200 dark:border-dark-400 hover:bg-gray-50 dark:hover:bg-dark-100">
                <td className="py-3 px-4 font-medium">Inactive Customers Reactivation</td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">Inactive 90 Days</td>
                <td className="py-3 px-4 text-center">3,450</td>
                <td className="py-3 px-4 text-center">3,450</td>
                <td className="py-3 px-4 text-center text-success-600">3,100</td>
                <td className="py-3 px-4 text-center text-error-600">350</td>
                <td className="py-3 px-4 text-center">89.9%</td>
              </tr>
              <tr className="border-b border-gray-200 dark:border-dark-400 hover:bg-gray-50 dark:hover:bg-dark-100">
                <td className="py-3 px-4 font-medium">New Product Announcement</td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">Frequent Buyers</td>
                <td className="py-3 px-4 text-center">890</td>
                <td className="py-3 px-4 text-center">890</td>
                <td className="py-3 px-4 text-center text-success-600">850</td>
                <td className="py-3 px-4 text-center text-error-600">40</td>
                <td className="py-3 px-4 text-center">95.5%</td>
              </tr>
              <tr className="border-b border-gray-200 dark:border-dark-400 hover:bg-gray-50 dark:hover:bg-dark-100">
                <td className="py-3 px-4 font-medium">Feedback Survey</td>
                <td className="py-3 px-4 text-gray-600 dark:text-gray-300">Recent Purchasers</td>
                <td className="py-3 px-4 text-center">720</td>
                <td className="py-3 px-4 text-center">650</td>
                <td className="py-3 px-4 text-center text-success-600">600</td>
                <td className="py-3 px-4 text-center text-error-600">50</td>
                <td className="py-3 px-4 text-center">92.3%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Reports;