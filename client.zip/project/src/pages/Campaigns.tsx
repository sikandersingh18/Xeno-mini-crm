import React, { useState, useEffect } from 'react';
import { Search, Calendar, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';

interface Campaign {
  id: string;
  name: string;
  segment: string;
  createdAt: Date;
  status: 'Completed' | 'In Progress' | 'Failed';
  audience: number;
  sent: number;
  delivered: number;
  failed: number;
}

const sampleCampaigns: Campaign[] = [
  {
    id: '1',
    name: 'Summer Sale Promo',
    segment: 'High Spenders',
    createdAt: new Date('2025-05-28T10:30:00'),
    status: 'Completed',
    audience: 1250,
    sent: 1250,
    delivered: 1150,
    failed: 100
  },
  {
    id: '2',
    name: 'Inactive Customers Reactivation',
    segment: 'Inactive 90 Days',
    createdAt: new Date('2025-05-26T14:15:00'),
    status: 'Completed',
    audience: 3450,
    sent: 3450,
    delivered: 3100,
    failed: 350
  },
  {
    id: '3',
    name: 'New Product Announcement',
    segment: 'Frequent Buyers',
    createdAt: new Date('2025-05-24T09:45:00'),
    status: 'Completed',
    audience: 890,
    sent: 890,
    delivered: 850,
    failed: 40
  },
  {
    id: '4',
    name: 'Feedback Survey',
    segment: 'Recent Purchasers',
    createdAt: new Date('2025-05-22T16:20:00'),
    status: 'In Progress',
    audience: 720,
    sent: 650,
    delivered: 600,
    failed: 50
  }
];

const Campaigns: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch
    setTimeout(() => {
      setCampaigns(sampleCampaigns);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredCampaigns = campaigns.filter(campaign => 
    campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    campaign.segment.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusIcon = (status: Campaign['status']) => {
    switch (status) {
      case 'Completed':
        return <CheckCircle className="h-4 w-4 text-success-500" />;
      case 'In Progress':
        return <AlertCircle className="h-4 w-4 text-warning-500" />;
      case 'Failed':
        return <XCircle className="h-4 w-4 text-error-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Campaigns</h1>
        <Link to="/segments/create" className="btn btn-primary">
          Create Campaign
        </Link>
      </div>

      <div className="card">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="font-semibold">Campaign History</h2>
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                className="input pl-9 w-full py-2"
                placeholder="Search campaigns..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select className="input py-2">
              <option value="all">All Statuses</option>
              <option value="completed">Completed</option>
              <option value="in-progress">In Progress</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-dark-400">
                  <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Campaign Name</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Segment</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-500 dark:text-gray-400">Date</th>
                  <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Status</th>
                  <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Audience Size</th>
                  <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Sent</th>
                  <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Delivered</th>
                  <th className="py-3 px-4 text-center font-medium text-gray-500 dark:text-gray-400">Failed</th>
                </tr>
              </thead>
              <tbody>
                {filteredCampaigns.map((campaign) => (
                  <tr key={campaign.id} className="border-b border-gray-200 dark:border-dark-400 hover:bg-gray-50 dark:hover:bg-dark-100">
                    <td className="py-3 px-4 font-medium">{campaign.name}</td>
                    <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{campaign.segment}</td>
                    <td className="py-3 px-4 text-gray-600 dark:text-gray-300">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                        {format(campaign.createdAt, 'MMM dd, yyyy HH:mm')}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-center">
                        <div className={`flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          campaign.status === 'Completed' ? 'bg-success-50 text-success-700' :
                          campaign.status === 'In Progress' ? 'bg-warning-50 text-warning-700' :
                          'bg-error-50 text-error-700'
                        }`}>
                          {getStatusIcon(campaign.status)}
                          <span className="ml-1">{campaign.status}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">{campaign.audience.toLocaleString()}</td>
                    <td className="py-3 px-4 text-center">{campaign.sent.toLocaleString()}</td>
                    <td className="py-3 px-4 text-center text-success-600">{campaign.delivered.toLocaleString()}</td>
                    <td className="py-3 px-4 text-center text-error-600">{campaign.failed.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Campaigns;