import React, { useState } from 'react';
import { ArrowLeft, Plus, X, Users } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import RuleBuilder from '../components/segments/RuleBuilder';
import toast from 'react-hot-toast';

const CreateSegment: React.FC = () => {
  const navigate = useNavigate();
  const [segmentName, setSegmentName] = useState('');
  const [segmentDescription, setSegmentDescription] = useState('');
  const [audienceSize, setAudienceSize] = useState<number | null>(null);
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);

  const handlePreviewAudience = () => {
    if (!segmentName) {
      toast.error('Please enter a segment name');
      return;
    }
    
    setIsPreviewLoading(true);
    
    // Simulate API call to calculate audience size
    setTimeout(() => {
      // Random audience size between 500 and 5000
      const size = Math.floor(Math.random() * 4500) + 500;
      setAudienceSize(size);
      setIsPreviewLoading(false);
    }, 1500);
  };

  const handleSaveSegment = () => {
    if (!segmentName) {
      toast.error('Please enter a segment name');
      return;
    }
    
    if (!audienceSize) {
      toast.error('Please preview your audience first');
      return;
    }
    
    // Simulate saving the segment
    toast.success('Segment saved successfully!');
    
    // Navigate to campaigns page
    setTimeout(() => {
      navigate('/campaigns');
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Link to="/segments" className="mr-4 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-dark-100">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <h1 className="text-2xl font-semibold">Create Audience Segment</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <h2 className="font-semibold mb-4">Segment Details</h2>
            <div className="space-y-4">
              <div>
                <label htmlFor="segmentName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Segment Name*
                </label>
                <input
                  id="segmentName"
                  type="text"
                  className="input w-full"
                  placeholder="e.g., High Value Customers"
                  value={segmentName}
                  onChange={(e) => setSegmentName(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="segmentDescription" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Segment Description
                </label>
                <textarea
                  id="segmentDescription"
                  className="input w-full resize-none"
                  rows={3}
                  placeholder="Describe your audience segment..."
                  value={segmentDescription}
                  onChange={(e) => setSegmentDescription(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          <div className="card">
            <h2 className="font-semibold mb-4">Segment Rules</h2>
            <div className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              Define rules to identify your target audience. Combine conditions using AND/OR operators.
            </div>
            
            <RuleBuilder />
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="card">
            <h2 className="font-semibold mb-4">Audience Preview</h2>
            <div className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              Preview the size of your audience before saving the segment.
            </div>
            
            {audienceSize ? (
              <div className="bg-primary-50 dark:bg-dark-100 rounded-lg p-4 flex items-center justify-center flex-col">
                <div className="text-primary-600 dark:text-primary-400 text-3xl font-bold flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  {audienceSize.toLocaleString()}
                </div>
                <div className="text-gray-600 dark:text-gray-300 text-sm mt-1">
                  Customers match your criteria
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 dark:bg-dark-100 rounded-lg p-4 flex items-center justify-center flex-col">
                <Users className="h-8 w-8 text-gray-400 mb-2" />
                <div className="text-gray-600 dark:text-gray-300 text-sm text-center">
                  Click the Preview button to see how many customers match your criteria
                </div>
              </div>
            )}
            
            <div className="mt-4">
              <button 
                className="btn btn-secondary w-full"
                onClick={handlePreviewAudience}
                disabled={isPreviewLoading}
              >
                {isPreviewLoading ? 'Calculating...' : 'Preview Audience'}
              </button>
            </div>
          </div>
          
          <div className="card">
            <h2 className="font-semibold mb-4">Actions</h2>
            <div className="space-y-3">
              <button 
                className="btn btn-primary w-full"
                onClick={handleSaveSegment}
              >
                Save & Create Campaign
              </button>
              <button className="btn btn-ghost w-full">
                Save Segment Only
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateSegment;