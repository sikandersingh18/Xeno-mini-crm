import React from 'react';
import { BarChart3, ArrowUpRight, ArrowDownRight, Users, Mail, AlertCircle } from 'lucide-react';
import MetricCard from '../components/dashboard/MetricCard';
import CampaignStatusChart from '../components/dashboard/CampaignStatusChart';
import RecentCampaigns from '../components/dashboard/RecentCampaigns';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <div>
          <button className="btn btn-primary">Create Campaign</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Audience"
          value="24,521"
          change={12.5}
          changeType="increase"
          icon={<Users className="h-6 w-6" />}
          iconColor="bg-primary-100 text-primary-600"
        />
        <MetricCard
          title="Active Segments"
          value="18"
          change={4.3}
          changeType="increase"
          icon={<Users className="h-6 w-6" />}
          iconColor="bg-secondary-100 text-secondary-600"
        />
        <MetricCard
          title="Campaigns Sent"
          value="342"
          change={8.7}
          changeType="increase"
          icon={<Mail className="h-6 w-6" />}
          iconColor="bg-success-100 text-success-600"
        />
        <MetricCard
          title="Failed Deliveries"
          value="64"
          change={2.1}
          changeType="decrease"
          icon={<AlertCircle className="h-6 w-6" />}
          iconColor="bg-error-100 text-error-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold">Campaign Performance</h2>
            <select className="input py-1">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 90 days</option>
            </select>
          </div>
          <CampaignStatusChart />
        </div>
        
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold">Recent Campaigns</h2>
            <button className="text-primary-600 text-sm font-medium">View All</button>
          </div>
          <RecentCampaigns />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;